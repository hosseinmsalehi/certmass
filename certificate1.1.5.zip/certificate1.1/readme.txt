=== certificate ===
author: jixa free lancer group 
Contributors: hosseinsalehi
author URI: https://jixa.ir
Donate link: https://jixa.ir
plugin URI: https://jixa.ir
Tags: certificate, inquiry, استعلام مدرک
Requires at least: 4.0
Tested up to: 5.4
افزونه کامل برای ثبت و استعلام مدرک و گواهینامه 
== Description ==
از طریق این افزونه می توان گواهی و یا مدارک صادر شده را ثبت کرد و کاربران می توانند استعلام مدارک خود را بگیرند
= امکانات =
* ثبت مدارک و گواهینامه ها
* استعلام مدارک توسط کاربران
* استفاده آسان با استفاده از کد کوتاه